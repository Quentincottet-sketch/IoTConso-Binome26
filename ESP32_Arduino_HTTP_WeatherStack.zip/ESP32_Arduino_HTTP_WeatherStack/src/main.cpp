
#include <Arduino.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <WiFi.h>

#define PREFIX "[Binome 26 - QUENTIN & ANTOINE] "

// A remplacer par vos informations
#define WEATHERSTACK_API_KEY "04736048ff6231df79d31a8770806140"

const char* ssid = "iPhone de Leo (2)";
const char* password = "quentin28010";

void setup() {
    Serial.begin(115200);
    delay(1000);

    Serial.println(PREFIX "Connexion au WiFi...");

    WiFi.begin(ssid, password);

    unsigned long start = millis();

    while (WiFi.status() != WL_CONNECTED &&
           millis() - start < 20000) {
        delay(500);
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.println(PREFIX "WiFi connecte !");
        Serial.print(PREFIX "Adresse IP : ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println(PREFIX "Echec de connexion WiFi");
    }
}

void loop() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println(PREFIX "Reconnexion WiFi...");
        WiFi.reconnect();
        delay(5000);
        return;
    }

    HTTPClient http;

    // URL HTTP utilisee dans l'exemple du professeur
    String url =
        String("http://api.weatherstack.com/current?access_key=")
        + WEATHERSTACK_API_KEY
        + "&query=Paris";

    Serial.println(PREFIX "Requete meteo en cours...");

    http.begin(url);
    int httpCode = http.GET();

    if (httpCode == HTTP_CODE_OK) {
        String payload = http.getString();

        JsonDocument doc;
        DeserializationError error =
            deserializeJson(doc, payload);

        if (error) {
            Serial.println(PREFIX "Erreur de lecture JSON");
        } else if (!doc["success"].isNull()
                   && doc["success"] == false) {
            Serial.print(PREFIX "Erreur API : ");
            Serial.println(
                doc["error"]["info"].as<String>()
            );
        } else if (doc["location"].isNull()
                   || doc["current"].isNull()) {
            Serial.println(PREFIX "Donnees meteo absentes");
        } else {
            String ville =
                doc["location"]["name"].as<String>();

            String heure =
                doc["location"]["localtime"].as<String>();

            float temperature =
                doc["current"]["temperature"].as<float>();

            float vent =
                doc["current"]["wind_speed"].as<float>();

            Serial.print(PREFIX "Ville : ");
            Serial.println(ville);

            Serial.print(PREFIX "Heure locale : ");
            Serial.println(heure);

            Serial.print(PREFIX "Temperature : ");
            Serial.print(temperature);
            Serial.println(" C");

            Serial.print(PREFIX "Vent : ");
            Serial.print(vent);
            Serial.println(" km/h");
        }
    } else {
        Serial.print(PREFIX "Erreur HTTP : ");
        Serial.println(httpCode);
    }

    http.end();

    // Nouvelle requete apres 60 secondes
    delay(60000);
}
