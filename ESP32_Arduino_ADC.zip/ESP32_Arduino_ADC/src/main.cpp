
#include <Arduino.h>

const int BUTTON_PIN = 32;
const int LED_PIN = 2;

int compteur = 0;

bool ancienEtat = LOW;
bool boutonAppuye = false;

void setup() {
    Serial.begin(115200);

    pinMode(BUTTON_PIN, INPUT);
    pinMode(LED_PIN, OUTPUT);

    digitalWrite(LED_PIN, LOW);

    Serial.println("[Binome 26 - QUENTIN & ANTOINE] Programme demarre");
}

void loop() {

    bool etatActuel = digitalRead(BUTTON_PIN);

    // Detection de l'appui
    if (etatActuel == HIGH && ancienEtat == LOW) {
        boutonAppuye = true;
        digitalWrite(LED_PIN, HIGH);
    }

    // Detection du relachement
    if (etatActuel == LOW && ancienEtat == HIGH && boutonAppuye) {

        digitalWrite(LED_PIN, LOW);
        compteur++;

        Serial.print("[Binome 26 - QUENTIN & ANTOINE] Nombre d'appuis : ");
        Serial.println(compteur);

        boutonAppuye = false;
    }

    ancienEtat = etatActuel;

    delay(20);
}
