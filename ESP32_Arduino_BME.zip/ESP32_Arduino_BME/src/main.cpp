
#include <Arduino.h>

#define LED_PIN 2
#define PREFIX "[Binome 26 - QUENTIN & ANTOINE] "

void setup() {
    Serial.begin(115200);
    pinMode(LED_PIN, OUTPUT);
    Serial.println(PREFIX "Mode NORMAL");
}

void loop() {
    digitalWrite(LED_PIN, HIGH);
    delay(1300);

    digitalWrite(LED_PIN, LOW);
    delay(700);
}
